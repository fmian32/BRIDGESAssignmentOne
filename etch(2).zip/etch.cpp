
#include <iostream>
#include "face.h"

using namespace bridges::game;
using namespace std;



int main() {
  // Create an instance of smiley
  face nbg(1, "fmian32", "712150494260");

  // Start the game
  nbg.start();

  return 0;
}