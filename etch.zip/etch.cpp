#include "NonBlockingGame.h"
#include <iostream>

using namespace bridges::game;
using namespace std;

class Smiley : public NonBlockingGame { 
  private: 
    int eyelevel = 2;
    int eyeverticalone = 2; 
    int eyeverticaltwo = 7;
    int smilelevel = 7; 
  public:
    // First the constructor must be overwritten and the size of the grid passed in
    Smiley(int assignmentID, std::string username, std::string apikey)
      : NonBlockingGame(assignmentID, username, apikey, 10, 10) {}

    virtual void initialize() override {
      // Set the title for the game which will show up as a title on the page
      setTitle("Face");
      // Set a description which will show under the title
      setDescription("Draw a happy face on your game grid");

      int i,j;

      // do all of your drawing of the face here, two eyes and a smiley 
      //Nested for loops iterate over the board and create the initial smily
      for(i = 0; i<getBoardHeight(); i++) 
      { 
        for(j = 0; j<getBoardWidth();j++) 
        { 
          setBGColor(i,j,NamedColor::green); //backdrop
        if(i == eyelevel&&(j==eyeverticalone||j==eyeverticaltwo)) //create eyes
        {  
          //cout<<i<<" "<<j<<endl;
          setBGColor(i,j,NamedColor::yellow); 
          drawSymbol(i,j,NamedSymbol::circle,NamedColor::black);
        }
        
        if(i==(smilelevel-2)&&(j==(eyeverticalone-1)||j==(eyeverticaltwo+1)))//create horizontal smile
        { 
          setBGColor(i,j,NamedColor::blue); 
        }
        if(i==(smilelevel-1)&&(j==eyeverticalone||j==eyeverticaltwo))//create dimple set 2
        { 
           setBGColor(i,j,NamedColor::blue);
        }
        
        if(i==smilelevel&&(j>=(eyeverticalone+1)&&j<=(eyeverticaltwo-1)))//create dimple set 1(first blue boxes from the middle)
        { 
         setBGColor(i,j,NamedColor::blue);
        } 
        } 
      }
    }

    // Game loop must be overwriten to complete the abstract class however,
    // it will not be used here. It is called every frame of the game loop.
    virtual void gameLoop() override {

      // wont have anything here for this assignment  
      if(keyUp()) { 
        for(int i = 0; i<getBoardHeight();i++) 
        { 
          for(int j = 0; j<getBoardWidth();j++) 
          { 
            setBGColor(i,j,NamedColor::ivory); //create backdrop
            if(i==eyelevel&&(j==eyeverticalone||j==eyeverticaltwo))//set eye backdrop
            { 
              setBGColor(i,j,NamedColor::red);
            }
            if((i==smilelevel||i==smilelevel-4)&&(j>=eyeverticalone+1&&j<=eyeverticaltwo-1))//set base smile
            { 
              setBGColor(i,j,NamedColor::black); 
            }
            if((i==smilelevel-1||i==smilelevel-3)&&(j==eyeverticalone||j==eyeverticaltwo))//set dimple set 1
            { 
              setBGColor(i,j,NamedColor::black); 
            }
            if((i==smilelevel-2)&&(j==eyeverticalone-1||j==eyeverticaltwo+1)) //set dimple set 2
            { 
              setBGColor(i,j,NamedColor::black);
            }
            if((i==smilelevel-1||i==smilelevel-3)&&(j>=(eyeverticalone+1)&&j<=(eyeverticaltwo-1)))//color mouth set 1
            { 
              setBGColor(i,j,NamedColor::red);
            }
            if((i==smilelevel-2)&&(j>=eyeverticalone&&j<=eyeverticaltwo))//color mout set 2(base mouth line)
            { 
              setBGColor(i,j,NamedColor::red);
              if(j==eyeverticalone+1) 
              { 
                drawSymbol(i,j,NamedSymbol::B,NamedColor::white);//create BOO symbol (with bomb icon at the end)
              }
              if(j==eyeverticalone+2||j==eyeverticalone+3) 
              { 
                drawSymbol(i,j,NamedSymbol::O,NamedColor::white);
              }
              if(j==eyeverticalone+4) 
              { 
                drawSymbol(i,j,NamedSymbol::bomb, NamedColor::black);
              }
            }
          }
        } 

      } 

      if(keyDown()) 
      { 
        int i,j;
        /* 
         nested for loops repeated from initialize()/ allows user to toggle back and forth between boo! screen and original smiley
        */
       for(i = 0; i<getBoardHeight(); i++) 
      { 
        for(j = 0; j<getBoardWidth();j++) 
        { 
          setBGColor(i,j,NamedColor::green); 
        if(i == eyelevel&&(j==eyeverticalone||j==eyeverticaltwo)) 
        {  
          //cout<<i<<" "<<j<<endl;
          setBGColor(i,j,NamedColor::yellow); 
          drawSymbol(i,j,NamedSymbol::circle,NamedColor::black);
        }
        
        if(i==(smilelevel-2)&&(j==(eyeverticalone-1)||j==(eyeverticaltwo+1)))
        { 
          setBGColor(i,j,NamedColor::blue); 
        }
        if(i==(smilelevel-1)&&(j==eyeverticalone||j==eyeverticaltwo)) 
        { 
           setBGColor(i,j,NamedColor::blue);
        }
        
        if(i==smilelevel&&(j>=(eyeverticalone+1)&&j<=(eyeverticaltwo-1))) 
        { 
         setBGColor(i,j,NamedColor::blue);
        }

        if((i==smilelevel-2)&&(j>=(eyeverticalone+1)&&j<=(eyeverticaltwo-1))) 
        { 
          drawSymbol(i,j,NamedSymbol::none,NamedColor::red);
        } 
        } 
      }
      } 

      if(keyQ()) 
      { 
        exit(1);//exit program
      } 


    }

};

int main() {
  // Create an instance of smiley
  Smiley nbg(1, "fmian32", "712150494260");

  // Start the game
  nbg.start();

  return 0;
}